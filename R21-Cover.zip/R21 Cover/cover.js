// R21 Cover — hides FUTBIN / FUT.GG from Chrome's very first frame on R21 screens, so the plain site never flashes before R21 is up.
// Runs before the page draws (document_start). Reads R21's own settings (localStorage "r21_cover", written by the highlighter).
// Needs the R21 Deal Highlighter (Tampermonkey) — the highlighter takes over from this cover once its screen is ready.
(function () {
  if (window.__r21cover) return; window.__r21cover = 1;
  function r21Cover(S) {   // S = { paused, classic, minp } — R21's settings (the main script mirrors them into this site's localStorage)
    try {
      const fb = location.hostname.includes('futbin'), P = location.pathname, de0 = () => document.documentElement;
      const ex = document.getElementById('r21pre'); if (ex) return { kind: ex.dataset.kind, wrap: ex, t0: +ex.dataset.t0 || Date.now() };
      // 5.4.330: the R21 Cover extension hides these pages from Chrome's own first frame — every way out of the cover says "show" once
      const show = () => { const go = () => document.documentElement.classList.add('r21-show'); if (de0()) go(); else { const mo = new MutationObserver(() => { if (de0()) { mo.disconnect(); go(); } }); mo.observe(document, { childList: true }); } };
      if (sessionStorage.getItem('r21_tab_off') === '1' || S.paused || S.classic) { show(); return null; }
      let kind = null;
      // FUTBIN's home page is never shown — straight to your deals (5.4.329, Rick: "why is it showing futbin, it shouldnt be")
      if (fb && (P === '/' || P === '') && !location.search) kind = 'home';
      else if (fb ? P.startsWith('/27/market-player-list') : P.startsWith('/players/momentum')) kind = innerWidth >= 420 ? 'list' : null;
      else if (fb ? /^\/27\/player\/\d+/.test(P) : /^\/players\/\d+-[^/]+\/27-\d+/.test(P)) kind = innerWidth >= 700 ? 'card' : null;
      else if (fb && /^\/27\/totw\/[^/]+/.test(P) && sessionStorage.getItem('r21_sq_off') !== '1') kind = 'sq';
      if (!kind) { show(); return null; }
      const R = { kind, t0: Date.now() };
      const mount = () => { const de = de0(); de.classList.add('r21-pre');
        const st = document.createElement('style'); st.id = 'r21-pre-css';
        st.textContent = 'html{background:#03141a!important}body{visibility:hidden!important}body>[id^="r21"]{visibility:visible!important}' +
          '#r21pre{position:fixed;left:0;top:0;right:0;bottom:0;z-index:99995;pointer-events:none;transition:opacity .12s ease;' +
          'background:radial-gradient(900px 500px at 75% -10%,#0f4c55 0%,transparent 60%),radial-gradient(700px 500px at -5% 110%,#0b3b44 0%,transparent 60%),linear-gradient(160deg,#052228,#03141a)}' +
          '#r21pre.out{opacity:0}#r21pre *,#r21pre *:before,#r21pre *:after{animation:none!important;transition:none!important}';   // 5.4.396: the still copy never animates
        de.appendChild(st);
        const wrap = document.createElement('div'); wrap.id = 'r21pre'; wrap.dataset.kind = kind; wrap.dataset.t0 = String(R.t0); de.appendChild(wrap); R.wrap = wrap;
        if (kind === 'home') return;
        try {
          // the screen you left in this tab — or (5.4.330) for the deals list, the newest deals screen from ANY tab (new tab, typed futbin.com)
          const LIST = fb ? /^\/27\/market-player-list/ : /^\/players\/momentum/, fits = (sn, css) => sn && css && Date.now() - sn.at < 20 * 60e3 && Math.abs(sn.w - innerWidth) < 4 && Math.abs(sn.h - innerHeight) < 4 &&
            (sn.path === P + location.search || (kind === 'list' && LIST.test(sn.path)));
          let sn = JSON.parse(sessionStorage.getItem('r21_snapv') || 'null'), css = sessionStorage.getItem('r21_snapcss');
          if (!fits(sn, css) && kind === 'list') { try { const s2 = JSON.parse(localStorage.getItem('r21_snapL') || 'null'), c2 = localStorage.getItem('r21_snapLcss'); if (fits(s2, c2)) { sn = s2; css = c2; } } catch (e) {} }
          if (fits(sn, css)) {
            const fl = document.createElement('link'); fl.rel = 'stylesheet'; fl.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Poppins:wght@600;700;800&display=swap'; de.appendChild(fl);
            const sc = document.createElement('style'); sc.id = 'r21-pre-snapcss'; sc.textContent = css.replace(/#r21(v|sq)(?![\w-])/g, '#r21$1p'); de.appendChild(sc);
            (sn.hc || []).forEach(c => de.classList.add(c));
            const c = document.createElement('div'); c.id = sn.id + 'p'; c.className = sn.cls || ''; if (sn.dm) c.dataset.m = sn.dm; c.innerHTML = sn.html; wrap.appendChild(c);
            ['.rv-list', '.rv-detail', '.cll', '.tbl'].forEach((q, i) => { const e = c.querySelector(q); if (e && sn.sc && sn.sc[i]) e.scrollTop = sn.sc[i]; });
            wrap.style.background = 'none';
          }
        } catch (e) {} };
      if (de0()) mount();
      else { const mo = new MutationObserver(() => { if (de0()) { mo.disconnect(); mount(); } }); mo.observe(document, { childList: true }); }
      if (kind === 'home') location.replace('https://www.futbin.com/27/market-player-list?ps_price=' + ((+S.minp) || 26000) + '%2B&sort=ps_trend&order=asc');
      return R;
    } catch (e) { return null; }
  }

  let S = {}; try { S = JSON.parse(localStorage.getItem('r21_cover') || '{}') || {}; } catch (e) {}
  const R = r21Cover(S);
  // safety net: if the highlighter isn't running (Tampermonkey off / not installed), never leave the page covered
  setTimeout(() => { try { const de = document.documentElement; if (!de || de.classList.contains('r21-show')) return;
    de.classList.remove('r21-pre'); de.classList.add('r21-show');
    ['r21pre', 'r21-pre-css', 'r21-pre-snapcss'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); }); } catch (e) {} }, 12000);
})();
